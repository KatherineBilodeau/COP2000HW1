//Katherine Bilodeau COP2000 Homework Assignment 1
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	// The recipe makes 6 pies. 
	const float recipe_cups_flour = 15.0;
	const float recipe_tbsp_sugar = 8.0;
	const float recipe_tbsp_salt = 3.0;
	const float recipe_cups_butter = 5.25;
	const float recipe_number_eggs = 6;
	const int initial_recipe_number //used for dividing
	float number_of_pies;
	

	cout << "How many pies would you like to make?";
	cin >> number_of_pies;

	float final_amt_flour = (recipe_cups_flour / initial_recipe_number)*number_of_pies;
	float final_amt_sugar = (recipe_tbsp_sugar / initial_recipe_number)*number_of_pies;
	float final_amt_salt = (recipe_tbsp_salt / initial_recipe_number)*number_of_pies;
	float final_amt_butter = (recipe_cups_butter / initial_recipe_number)*number_of_pies;

	cout << "Cups of flour needed: " << setprecision (2) << fixed << final_amt_flour << endl;
	cout << "Tablespoons of sugar needed: " << setprecision(2) << fixed << final_amt_sugar << endl;
	cout << "Tablespoons of salt needed: " << setprecision(2) << fixed << final_amt_salt << endl;
	cout << "Cups of butter needed: " << setprecision(2) << fixed << final_amt_butter << endl;
	// There is no need to divide by 6 for eggs because the amount of eggs needed will always be equal to the number of pies. 
	cout << "Number of eggs needed: " << number_of_pies << endl;

	return 0;

}